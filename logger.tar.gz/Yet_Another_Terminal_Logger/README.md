Runs only as root.

After run, relogin and check /var/log/messages.
All your inputted commands logged now.
